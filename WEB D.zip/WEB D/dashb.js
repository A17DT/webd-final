// Mood glow logic
let latestMood = "😴";

const avatar = document.querySelector(".avatar-glow img");

function updateMoodGlow(emoji) {
    latestMood = emoji;
    let color = "#d9c6f8";

    if (emoji === "😤") color = "#ffb3b3";
    else if (emoji === "😴") color = "#add8e6";
    else if (emoji === "😎") color = "#d2b4ff";

    avatar.style.boxShadow = `0 0 25px ${color}`;
}

// Avatar upload
document.getElementById("uploadAvatar").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) {
        const imgURL = URL.createObjectURL(file);
        document.getElementById("userAvatar").src = imgURL;
    }
});

// Fake data loader
window.onload = () => {
    document.getElementById("studyTime").textContent = "5h 30m";
    document.getElementById("streak").textContent = "🔥 4-day";
    document.getElementById("completedTasks").textContent = "23";
    document.getElementById("moodLogs").textContent = "15";
    document.getElementById("favMood").textContent = "😎 Mood Slayer Mode";

    updateMoodGlow("😎");

    document.getElementById("journalEntries").innerHTML = `
    <p>🌙 "Felt sleepy but focused today."</p>
    <p>💖 "Did my reading! I’m proud ✨"</p>
  `;
};
